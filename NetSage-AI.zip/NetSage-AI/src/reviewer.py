import csv
import os
from datetime import datetime


LOG_FILE = "data/human_review_log.csv"


def initialize_review_log():
    if not os.path.exists(LOG_FILE):
        with open(LOG_FILE, "w", newline="", encoding="utf-8") as file:
            writer = csv.writer(file)

            writer.writerow([
                "timestamp",
                "case_id",
                "ai_diagnosis",
                "human_decision",
                "final_diagnosis",
                "reviewer_notes"
            ])


def save_review(
    case_id,
    ai_diagnosis,
    human_decision,
    final_diagnosis,
    reviewer_notes
):
    initialize_review_log()

    with open(LOG_FILE, "a", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)

        writer.writerow([
            datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            case_id,
            ai_diagnosis,
            human_decision,
            final_diagnosis,
            reviewer_notes
        ])

    return True