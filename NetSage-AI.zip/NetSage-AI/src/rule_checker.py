def create_issue(issue, severity, evidence, recommendation):
    return {
        "issue": issue,
        "severity": severity,
        "evidence": evidence,
        "recommendation": recommendation
    }


def check_interface_down(show_output):
    issues = []

    if "administratively down" in show_output.lower():
        issues.append(
            create_issue(
                "Interface is administratively down",
                "High",
                "The show output contains 'administratively down'",
                "Check the interface and use 'no shutdown' if appropriate."
            )
        )

    return issues


def check_missing_vlan(show_output):
    issues = []

    output = show_output.lower()

    if "vlan missing" in output:
        issues.append(
            create_issue(
                "Required VLAN is missing",
                "High",
                "The show output indicates that the VLAN is missing",
                "Create the required VLAN and assign the correct switch ports."
            )
        )

    if "not allowed on trunk" in output:
        issues.append(
            create_issue(
                "VLAN is not allowed on trunk",
                "Medium",
                "The VLAN is not included in the trunk configuration",
                "Allow the required VLAN on the trunk interface."
            )
        )

    return issues


def check_gateway(show_output):
    issues = []

    output = show_output.lower()

    if "default gateway field is empty" in output:
        issues.append(
            create_issue(
                "Default gateway is missing",
                "High",
                "No default gateway is configured",
                "Configure the correct default gateway for the host."
            )
        )

    if "incorrect default gateway" in output or "gateway mismatch" in output:
        issues.append(
            create_issue(
                "Default gateway mismatch",
                "High",
                "Configured gateway does not match the network router",
                "Update the host with the correct gateway address."
            )
        )

    return issues


def check_routing(show_output):
    issues = []

    output = show_output.lower()

    if "route missing" in output or "remote network route missing" in output:
        issues.append(
            create_issue(
                "Required route is missing",
                "High",
                "The routing table does not contain the required route",
                "Configure a static route or verify the dynamic routing protocol."
            )
        )

    if "incorrect next-hop" in output:
        issues.append(
            create_issue(
                "Incorrect next-hop address",
                "High",
                "The route uses an incorrect next-hop",
                "Update the route with the correct next-hop address."
            )
        )

    return issues


def check_dhcp(show_output):
    issues = []

    output = show_output.lower()

    if "0 available addresses" in output:
        issues.append(
            create_issue(
                "DHCP pool exhausted",
                "High",
                "The DHCP pool has no available addresses",
                "Expand the DHCP pool or remove unused leases."
            )
        )

    if "no ip helper-address" in output:
        issues.append(
            create_issue(
                "DHCP relay is missing",
                "High",
                "No ip helper-address is configured for remote DHCP clients",
                "Configure the correct ip helper-address on the router interface."
            )
        )

    return issues


def check_acl(show_output):
    issues = []

    output = show_output.lower()

    if "implicit deny reached" in output:
        issues.append(
            create_issue(
                "ACL implicit deny is blocking traffic",
                "High",
                "Traffic is reaching the implicit deny rule",
                "Add an appropriate permit rule before the implicit deny."
            )
        )

    if "overly broad permit any rule" in output:
        issues.append(
            create_issue(
                "ACL is too permissive",
                "High",
                "The ACL contains an overly broad permit rule",
                "Restrict the ACL to only required hosts, networks, and services."
            )
        )

    return issues


def run_rule_checks(show_output):
    all_issues = []

    all_issues.extend(check_interface_down(show_output))
    all_issues.extend(check_missing_vlan(show_output))
    all_issues.extend(check_gateway(show_output))
    all_issues.extend(check_routing(show_output))
    all_issues.extend(check_dhcp(show_output))
    all_issues.extend(check_acl(show_output))

    return all_issues

