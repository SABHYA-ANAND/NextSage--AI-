import pandas as pd

df = pd.read_csv("data/cases.csv")

print("Total cases:", len(df))
print("\nCases by concept:")
print(df["concept"].value_counts())

print("\nDataset preview:")
print(df.head())