from reviewer import save_review


result = save_review(
    case_id="CASE001",
    ai_diagnosis="Interface is administratively down",
    human_decision="Accepted",
    final_diagnosis="Interface is administratively down",
    reviewer_notes="The diagnosis matches the evidence."
)


if result:
    print("Human review saved successfully!")