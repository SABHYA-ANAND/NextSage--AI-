from rule_checker import run_rule_checks


def create_diagnosis(rule_findings, show_output):
    root_causes = []
    evidence = []
    fix_steps = []

    for finding in rule_findings:
        root_causes.append(finding["issue"])
        evidence.append(finding["evidence"])
        fix_steps.append(finding["recommendation"])

    if not root_causes:
        return {
            "root_cause": "Insufficient evidence to determine the exact network fault",
            "osi_layer": "Unknown",
            "confidence": 40,
            "evidence": [
                "The Python rule checker did not detect a deterministic configuration error."
            ],
            "next_command": "show running-config",
            "fix_steps": [
                "Collect additional show-command outputs.",
                "Verify physical connectivity.",
                "Check VLAN, IP addressing, routing, and security configuration."
            ],
            "requires_human_review": True
        }

    output = show_output.lower()

    if "administratively down" in output:
        osi_layer = "Layer 1/2"
        next_command = "show running-config interface"

    elif "route" in output:
        osi_layer = "Layer 3"
        next_command = "show ip route"

    elif "dhcp" in output:
        osi_layer = "Layer 7"
        next_command = "show ip dhcp pool"

    elif "vlan" in output:
        osi_layer = "Layer 2"
        next_command = "show vlan brief"

    else:
        osi_layer = "Layer 3"
        next_command = "show running-config"

    return {
        "root_cause": "; ".join(root_causes),
        "osi_layer": osi_layer,
        "confidence": 85,
        "evidence": evidence,
        "next_command": next_command,
        "fix_steps": fix_steps,
        "requires_human_review": True
    }


def diagnose_network_problem(
    symptom,
    topology_note,
    show_output,
    rule_findings=None
):
    if rule_findings is None:
        rule_findings = run_rule_checks(show_output)

    return create_diagnosis(rule_findings, show_output)