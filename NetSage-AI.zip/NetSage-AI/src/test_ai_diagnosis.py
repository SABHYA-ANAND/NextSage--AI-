from ai_diagnosis import diagnose_network_problem
from rule_checker import run_rule_checks


symptom = "PC cannot reach remote network"

topology_note = """
The PC is connected to Router 1.
Router 1 should route traffic to a remote network.
"""

show_output = """
show ip interface brief

GigabitEthernet0/1 administratively down

show ip route

Remote network route missing
"""


rule_findings = run_rule_checks(show_output)


result = diagnose_network_problem(
    symptom,
    topology_note,
    show_output,
    rule_findings
)


print("\nNETSAGE AI DIAGNOSIS\n")

print("Root Cause:", result["root_cause"])
print("OSI Layer:", result["osi_layer"])
print("Confidence:", result["confidence"])

print("\nEvidence:")
for evidence in result["evidence"]:
    print("-", evidence)

print("\nNext Command:")
print(result["next_command"])

print("\nFix Steps:")
for step in result["fix_steps"]:
    print("-", step)

print("\nHuman Review Required:")
print(result["requires_human_review"])