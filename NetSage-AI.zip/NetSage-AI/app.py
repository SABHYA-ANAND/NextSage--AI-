import streamlit as st
import pandas as pd
import sys
import os

sys.path.append(os.path.join(os.path.dirname(__file__), "src"))

from rule_checker import run_rule_checks
from ai_diagnosis import diagnose_network_problem
from reviewer import save_review


st.set_page_config(
    page_title="NetSage AI",
    page_icon="🌐",
    layout="wide"
)


@st.cache_data
def load_cases():
    return pd.read_csv("data/cases.csv")


cases = load_cases()


st.title("🌐 NetSage AI")

st.subheader("AI-Assisted Network Troubleshooting with Human Review")

st.divider()


st.sidebar.title("Navigation")

page = st.sidebar.radio(
    "Go to",
    [
        "🏠 Home",
        "🔍 Diagnose Network",
        "👨‍💻 Human Review",
        "📊 Dashboard"
    ]
)


if page == "🏠 Home":

    st.header("Welcome to NetSage AI")

    st.write("""
    NetSage AI is an AI-assisted network troubleshooting system designed
    for Cisco-style networking labs.
    """)

    st.markdown("""
    ### How it works

    1. Select a network troubleshooting case
    2. Analyze symptoms and Cisco show-command output
    3. Run deterministic Python rule checks
    4. Generate a diagnosis
    5. Human reviewer accepts, edits, or rejects the diagnosis
    6. Save the final decision
    """)

    st.info("Every diagnosis requires human review before it is considered final.")


elif page == "🔍 Diagnose Network":

    st.header("Network Diagnosis")

    case_id = st.selectbox(
        "Select a troubleshooting case",
        cases["case_id"]
    )

    selected_case = cases[
        cases["case_id"] == case_id
    ].iloc[0]

    col1, col2 = st.columns(2)

    with col1:

        st.subheader("Network Problem")

        st.write("### Symptom")
        st.write(selected_case["symptom"])

        st.write("### Topology Note")
        st.write(selected_case["topology_note"])

        st.write("### Expected Category")
        st.info(selected_case["concept"])

    with col2:

        st.subheader("Cisco Evidence")

        st.code(
            selected_case["show_output"],
            language="text"
        )

    st.divider()

    if st.button("🔍 Analyze Network Problem", type="primary"):

        show_output = selected_case["show_output"]

        rule_findings = run_rule_checks(show_output)

        diagnosis = diagnose_network_problem(
            selected_case["symptom"],
            selected_case["topology_note"],
            show_output,
            rule_findings
        )

        st.session_state["diagnosis"] = diagnosis
        st.session_state["case_id"] = case_id

        st.success("Analysis completed successfully!")

        st.subheader("🤖 NetSage AI Diagnosis")

        st.write("### Root Cause")
        st.warning(diagnosis["root_cause"])

        col1, col2 = st.columns(2)

        with col1:
            st.metric(
                "Confidence",
                f'{diagnosis["confidence"]}%'
            )

        with col2:
            st.metric(
                "OSI Layer",
                diagnosis["osi_layer"]
            )

        st.write("### Evidence")

        for evidence in diagnosis["evidence"]:
            st.write("•", evidence)

        st.write("### Next Command")

        st.code(diagnosis["next_command"])

        st.write("### Recommended Fix Steps")

        for index, step in enumerate(
            diagnosis["fix_steps"],
            start=1
        ):
            st.write(f"{index}. {step}")

        st.info(
            "⚠️ This diagnosis is a recommendation and requires human review."
        )


elif page == "👨‍💻 Human Review":

    st.header("Human Review")

    if "diagnosis" not in st.session_state:

        st.warning(
            "Please analyze a network case first from the Diagnose Network page."
        )

    else:

        diagnosis = st.session_state["diagnosis"]
        case_id = st.session_state["case_id"]

        st.write("### Case ID")
        st.info(case_id)

        st.write("### AI Diagnosis")
        st.write(diagnosis["root_cause"])

        st.write("### AI Evidence")

        for evidence in diagnosis["evidence"]:
            st.write("•", evidence)

        st.divider()

        decision = st.radio(
            "Human Review Decision",
            ["Accepted", "Edited", "Rejected"]
        )

        final_diagnosis = st.text_area(
            "Final Diagnosis",
            value=diagnosis["root_cause"]
        )

        reviewer_notes = st.text_area(
            "Reviewer Notes"
        )

        if st.button("💾 Save Human Review", type="primary"):

            save_review(
                case_id=case_id,
                ai_diagnosis=diagnosis["root_cause"],
                human_decision=decision,
                final_diagnosis=final_diagnosis,
                reviewer_notes=reviewer_notes
            )

            st.success("Human review saved successfully!")


elif page == "📊 Dashboard":

    st.header("NetSage AI Dashboard")

    st.metric(
        "Total Troubleshooting Cases",
        len(cases)
    )

    st.subheader("Cases by Network Concept")

    concept_counts = cases["concept"].value_counts()

    st.bar_chart(concept_counts)

    st.subheader("Cases by Severity")

    severity_counts = cases["severity"].value_counts()

    st.bar_chart(severity_counts)

    st.subheader("Dataset")

    st.dataframe(cases, use_container_width=True)